import matplotlib.pyplot as plt

brands = ["Apple","Samsung","Xiaomi","OnePlus","Others"]
share = [30,25,20,15,10]

plt.pie(share, labels=brands, autopct="%1.1f%%")
plt.title("Market Share")
plt.show()
