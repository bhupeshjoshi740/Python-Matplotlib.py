import matplotlib.pyplot as plt

class1 = [50,60,70,80]
class2 = [55,65,75,85]
class3 = [60,70,80,90]

plt.violinplot([class1, class2, class3])
plt.title("Exam Scores Distribution")
plt.ylabel("Scores")
plt.show()
