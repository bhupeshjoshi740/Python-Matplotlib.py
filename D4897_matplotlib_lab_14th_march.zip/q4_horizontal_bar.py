import matplotlib.pyplot as plt

cities = ["Delhi","Mumbai","Chennai","Kolkata","Bangalore"]
population = [30,20,15,10,12]

plt.barh(cities, population)
plt.title("City Population")
plt.xlabel("Population")
plt.ylabel("Cities")
plt.show()
