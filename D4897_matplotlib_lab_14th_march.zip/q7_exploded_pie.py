import matplotlib.pyplot as plt

activities = ["Study","Sleep","Exercise","Entertainment"]
time = [6,8,2,4]
explode = [0.1,0,0,0]

plt.pie(time, labels=activities, explode=explode, autopct="%1.1f%%")
plt.title("Daily Activities")
plt.show()
