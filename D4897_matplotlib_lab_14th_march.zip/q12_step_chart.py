import matplotlib.pyplot as plt

time = [1,2,3,4,5,6]
consumption = [2,4,3,5,4,6]

plt.step(time, consumption)
plt.title("Electricity Consumption")
plt.xlabel("Time")
plt.ylabel("Units")
plt.show()
