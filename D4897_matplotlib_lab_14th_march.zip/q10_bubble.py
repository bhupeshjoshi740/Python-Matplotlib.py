import matplotlib.pyplot as plt

cities = ["A","B","C","D","E"]
area = [50,60,70,80,90]
population = [100,200,300,400,500]
gdp = [500,600,700,800,900]

plt.scatter(area, population, s=gdp)
plt.title("Population vs Area")
plt.xlabel("Area")
plt.ylabel("Population")
plt.show()
