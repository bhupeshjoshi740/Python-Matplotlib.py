import matplotlib.pyplot as plt

months = list(range(1,13))
sales = [200, 220, 250, 270, 300, 320, 350, 370, 390, 420, 450, 480]

plt.plot(months, sales, marker='o', color='blue')
plt.title("Monthly Sales")
plt.xlabel("Months")
plt.ylabel("Sales")
plt.show()
