import matplotlib.pyplot as plt

hours = [1,2,3,4,5,6,7,8]
marks = [20,30,40,50,60,70,80,90]

plt.scatter(hours, marks)
plt.title("Study vs Marks")
plt.xlabel("Hours Studied")
plt.ylabel("Marks")
plt.show()
