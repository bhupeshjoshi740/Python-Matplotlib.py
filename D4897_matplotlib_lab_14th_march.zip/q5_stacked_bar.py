import matplotlib.pyplot as plt

departments = ["CS","IT","ECE","ME"]
male = [50,40,30,20]
female = [40,30,20,10]

plt.bar(departments, male, label="Male")
plt.bar(departments, female, bottom=male, label="Female")

plt.title("Students by Gender")
plt.xlabel("Departments")
plt.ylabel("Count")
plt.legend()
plt.show()
