import matplotlib.pyplot as plt

months = [1,2,3,4,5,6]
A = [10,20,30,40,50,60]
B = [15,25,35,45,55,65]
C = [5,15,25,35,45,55]

plt.plot(months, A, label="Product A")
plt.plot(months, B, label="Product B")
plt.plot(months, C, label="Product C")

plt.title("Product Sales")
plt.xlabel("Months")
plt.ylabel("Sales")
plt.legend()
plt.show()
