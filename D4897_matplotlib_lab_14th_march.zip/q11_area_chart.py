import matplotlib.pyplot as plt

years = [2018,2019,2020,2021,2022,2023]
profit = [10,20,15,25,30,35]

plt.fill_between(years, profit)
plt.title("Profit Growth")
plt.xlabel("Years")
plt.ylabel("Profit")
plt.show()
