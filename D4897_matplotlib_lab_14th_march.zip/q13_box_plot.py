import matplotlib.pyplot as plt

dept1 = [20000,25000,30000,35000]
dept2 = [30000,35000,40000,45000]
dept3 = [15000,20000,25000,30000]

plt.boxplot([dept1, dept2, dept3])
plt.title("Salary Distribution")
plt.ylabel("Salary")
plt.show()
