import matplotlib.pyplot as plt
import numpy as np

marks = np.random.randint(0,100,100)

plt.hist(marks)
plt.title("Marks Distribution")
plt.xlabel("Marks")
plt.ylabel("Frequency")
plt.show()
