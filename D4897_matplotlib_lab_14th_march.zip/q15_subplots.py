import matplotlib.pyplot as plt

fig, axs = plt.subplots(2,2)

axs[0,0].plot([1,2,3],[10,20,30])
axs[0,0].set_title("Line")

axs[0,1].bar(["A","B","C"],[5,7,3])
axs[0,1].set_title("Bar")

axs[1,0].pie([30,40,30])
axs[1,0].set_title("Pie")

axs[1,1].scatter([1,2,3],[3,2,1])
axs[1,1].set_title("Scatter")

plt.tight_layout()
plt.show()
